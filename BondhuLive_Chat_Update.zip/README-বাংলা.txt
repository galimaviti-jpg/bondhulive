BondhuLive আসল টেক্সট চ্যাট চালু করার নির্দেশনা

১) Supabase Dashboard > SQL Editor > New query খুলুন।
২) setup-realtime.sql-এর কোড পেস্ট করে Run করুন।
৩) এই ZIP-এর index.html দিয়ে Netlify-র পুরোনো index.html প্রতিস্থাপন করুন।
   GitHub দিয়ে Netlify যুক্ত থাকলে GitHub repository-তে index.html আপডেট করে commit/push করুন; Netlify নিজে deploy করবে।
   Netlify-তে সরাসরি deploy করলে ZIP extract করে index.html-সহ ফাইলগুলো deploy করুন।
৪) দুইজন আলাদা ইমেইল দিয়ে রেজিস্ট্রেশন করুন। Supabase-এ email confirmation চালু থাকলে ইমেইল যাচাই করে লগইন করুন।
৫) দুইটি আলাদা ফোন/ব্রাউজারে দুই অ্যাকাউন্ট দিয়ে লগইন করুন। Friends তালিকায় একে অপরের নাম দেখাবে। নাম চাপুন, মেসেজ পাঠান।

এই সংস্করণে: প্রোফাইল তালিকা, টেক্সট মেসেজ পাঠানো/দেখা এবং messages টেবিলের realtime subscription যুক্ত।
এখনো নেই: ভয়েস/ভিডিও কল, লাইভ সম্প্রচার, গেম, পেমেন্ট/রিচার্জ, push notification।
Wallet শুধু ব্যালেন্স দেখায়; টাকা যোগ/কমানোর ব্যবস্থা নেই।
Supabase publishable key-ই শুধু HTML-এ রাখবেন। Secret বা service_role key কখনো প্রকাশ করবেন না।
