-- Messages টেবিল Supabase Realtime-এ যুক্ত করুন (আগে যুক্ত থাকলে কোনো পরিবর্তন হবে না)
do $$
begin
  if not exists (
    select 1 from pg_publication_tables
    where pubname = 'supabase_realtime'
      and schemaname = 'public'
      and tablename = 'messages'
  ) then
    alter publication supabase_realtime add table public.messages;
  end if;
end $$;